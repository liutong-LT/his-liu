package com.neuedu.mapper;

import com.neuedu.pojo.RegistLevel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 挂号级别 Mapper 接口
 * </p>
 *
 * @author jshand
 * @since 2020-08-25
 */
public interface RegistLevelMapper extends BaseMapper<RegistLevel> {

}
