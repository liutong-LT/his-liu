package com.neuedu.mapper;

import com.neuedu.pojo.InspectApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 检验申请 Mapper 接口
 * </p>
 *
 * @author jshand
 * @since 2020-08-25
 */
public interface InspectApplyMapper extends BaseMapper<InspectApply> {

}
