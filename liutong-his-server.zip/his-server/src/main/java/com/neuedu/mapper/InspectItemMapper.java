package com.neuedu.mapper;

import com.neuedu.pojo.InspectItem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 检验项目 Mapper 接口
 * </p>
 *
 * @author jshand
 * @since 2020-08-25
 */
public interface InspectItemMapper extends BaseMapper<InspectItem> {

}
