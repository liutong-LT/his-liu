export default {
  setToken: (state,token) => {state.token = token}
}
