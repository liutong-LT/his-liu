export default {
  token: ''
}