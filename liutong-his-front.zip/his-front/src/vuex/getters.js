export default {
  getToken: state => {return state.token}
}
